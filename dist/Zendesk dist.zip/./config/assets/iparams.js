app.initialized().then(function (client) {
    window.client = client;
    $(".ZD_authentication").hide();
    $(document).on('click', '#authBtn', function () {
        $("#authBtn").prop("disabled", true);
        if ($("#apiKey").val().trim() === "")
            $(".token_error").html("Please enter Freshchat API Key");
        else
            $(".token_error").html("");
        if ($("#apiKey").val().trim() !== "") {
            $("#authBtn").text("Authenticating...");
            getAgents(client);
        } else buttonEnable("authBtn");
    });
    $(document).on('click', '#ZDauthBtn', function () {
        $(this).prop("disabled", true);
        var emailPattern = /^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/;
        if ($("#password").val().trim() === "") {
            $("#password").attr("state", "error");
            $("#password").attr("state-text", "Please enter Password");
        }
        else {
            $("#password").removeAttr("state");
            $("#password").removeAttr("state-text");
        }
        if ($("#email").val().trim() === "") {
            $("#email").attr("state", "error");
            $("#email").attr("state-text", "Please enter Email");
        }
        else {
            if (emailPattern.test($("#email").val().trim()) === false) {
                $("#email").attr("state-text", "Please enter valid Email");
                $("#email").attr("state", "error");
            } else {
                $("#email").removeAttr("state");
                $("#email").removeAttr("state-text");
            }
        }
        if ($("#subdomain").val().trim() === "") {
            $("#subdomain").attr("state", "error");
            $("#subdomain").attr("state-text", "Please enter Subdomain");
        }
        else {
            $("#subdomain").removeAttr("state");
            $("#subdomain").removeAttr("state-text");
        }
        if ($("#password").val().trim() !== "" && emailPattern.test($("#email").val().trim()) && $("#subdomain").val().trim() !== "") {
            $("#ZDauthBtn").text("Authenticating...");
            getTicketDetails();
        } else {
            buttonEnable("ZDauthBtn");
        }
    });
    $(document).on('fwChange', '#subdomain,#password,#email', function () {
        buttonEnable("ZDauthBtn");
        $("#subdomain").removeAttr("state-text");
        $("#subdomain").removeAttr("state");
        $("#password").removeAttr("state-text");
        $("#email").removeAttr("state");
        $("#email").removeAttr("state-text");
        $("#password").removeAttr("state");
        $(".token_error_zd,.message_div,.error_div").html("");
    });
    $(document).on('change', 'textarea', function () {
        $(".token_error,.error_div").html("");
        buttonEnable("authBtn");
    });
}, function (error) {
    handleError(error, token_error);
});
function buttonEnable(id) {
    $("#" + id).text("Authenticate");
    $("#" + id).prop("disabled", false);
}
function getAgents(client) {
    var api_key = $("#apiKey").val();
    var headers = { "Authorization": "Bearer " + api_key };
    var options = { headers: headers };
    var url = `https://api.freshchat.com/v2/agents?items_per_page=2`;
    client.request.get(url, options).then(function () {
        $("#authBtn").text("Authenticated");
        $(".ZD_authentication").show();
        $(".authentication").hide();
        $(".error_div").html("");
    }, function (error) {
        handleError(error, "error_div");
        buttonEnable("authBtn");
    });
}
function getTicketDetails() {
    var sudomain = $("#subdomain").val().trim();
    var email = $("#email").val().trim();
    var password = $("#password").val().trim();
    var url = `https://${sudomain}/api/v2/tickets.json?page[size]=1`;
    console.log(url)
    console.log(sudomain)
    console.log(email)
    console.log(password)
    var headers = { "Authorization": `Basic ` + btoa(`${email}/token:${password}`) };
    var options = { headers: headers };
    console.log(headers)
    client.request.get(url, options).then(function () {
        $("#ZDauthBtn").text("Authenticated");
        $('.message_div').html("Integration setup successful");
        $(".token_error_zd").html("");
    }, function (error) {
        console.error(error);
        $('.token_error_zd').html("Integration setup failed. Please try again.");
        buttonEnable("ZDauthBtn");
    });
}
function handleError(error, errorid) {
    console.error(error)
    if (error.status === 400) {
        $('.' + errorid).html("Invalid Input entered, please verify the fields and try again.");
    } else if (error.status === 401 || error.status === 403) {
        $('.' + errorid).html("Invalid Credentials were given or Subscription to the service expired.");
    } else if (error.status === 404) {
        $('.' + errorid).html("Invalid Domain entered, please check the field and try again");
    } else if (error.status === 500) {
        $('.' + errorid).html("Unexpected error occurred, please try after sometime.");
    } else if (error.status === 502) {
        $('.' + errorid).html("Error in establishing a connection.");
    } else if (error.status === 504) {
        $('.' + errorid).html("Timeout error while processing the request.");
    } else {
        $('.' + errorid).html("Unexpected Error");
    }
}