var reqData = require('./lib/request_data');
var request = require('request');
var base64 = require('base-64');

exports = {
  events: [
    { event: "onMessageCreate", callback: "onMessageCreateCallback" }
  ],
  onMessageCreateCallback: function (payload) {
    console.log("MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM")
    var message_data = payload.data.message;
    console.log("DDDDDDDDDDDDDDDDDDDDDDDDDDDDDD")
    console.log(payload.data)
    console.log("mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm")
    console.log(message_data)
    console.log("OFFLINE CONDITION>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
    console.log(message_data.is_offline)
    console.log(payload.iparams.offlineVal)
    if (message_data.is_offline && payload.iparams.offlineVal) {
      // console.log(message_data.messages)
      var msg_arr = message_data.messages[0];
      console.log("MESSAGE ARRAY.....................")
      console.log(msg_arr)
      if (msg_arr.message_type === "normal") {
        var message_parts = message_data.messages[0].message_parts[0];
        console.log("MESSAGE PARTS...........")
        console.log(message_parts)
        console.log("MESSAGE CONTENT...................")
        console.log(message_parts.text.content)
        var content = message_parts.text.content;
        var emailExist = validateEmail(content);
        console.log(emailExist, " <- text is email?");
        if ("text" in message_parts && emailExist === false) {
          searchUser(content, payload);
          // getBusinessHours(today, message_parts.text.content, payload);
        }
      }

    }


    console.log(message_parts.text)
  },
  searchUser: function (args) {
    request(reqData.searchUser(args), function (err, resp, body) {
      if (err) {
        renderData(err);
      }
      if (resp !== undefined) {
        if (resp.statusCode === 200) {
          try {
            var respObj = JSON.parse(body);
            renderData(null, respObj);
          } catch (c_err) {
            renderData(c_err);
          }
        } else {
          var error = {
            status: resp.statusCode,
            message: body
          };
          renderData(error);
        }
      }

    });
  },
  searchTickets: function (args) {
    request(reqData.searchTickets(args), function (err, resp, body) {
      if (err) {
        renderData(err);
      }
      if (resp !== undefined) {
        if (resp.statusCode === 201 || resp.statusCode === 200) {
          try {
            var respObj = JSON.parse(body);
            renderData(null, respObj);
          } catch (c_err) {
            renderData(c_err);
          }
        } else {
          var error = {
            status: resp.statusCode,
            message: body
          };
          renderData(error);
        }
      }


    });
  },
  createTicket: function (args) {
    request(reqData.createTicket(args), function (err, resp, body) {
      if (err) {
        renderData(err);
      }
      if (resp !== undefined) {
        if (resp.statusCode === 201) {
          var reqObj = {
            "id": body.ticket.id,
            "requester_id": base64.encode(body.ticket.requester_id)
          };
          renderData(null, reqObj);
        } else {
          var error = {
            status: resp.statusCode,
            message: body
          };
          renderData(error);
        }
      }
    });
  }, getAllTickets: function (args) {
    request(reqData.searchAllTickets(args), function (err, resp, body) {
      if (err) {
        renderData(err);
      }
      if (resp !== undefined) {
        if (resp.statusCode === 201 || resp.statusCode === 200) {
          try {
            var respObj = JSON.parse(body);
            renderData(null, respObj);
          } catch (c_err) {
            renderData(c_err);
          }
        } else {
          var error = {
            status: resp.statusCode,
            message: body
          };
          renderData(error);
        }
      }

    });
  },
  getTicketFields: function (args) {
    request(reqData.getTicketFields(args), function (err, resp, body) {
      if (err) {
        renderData(err);
      }
      if (resp !== undefined && resp.statusCode === 200) {
        try {
          var respObj = JSON.parse(body);
          renderData(null, respObj);
        } catch (c_err) {
          renderData(c_err);
        }
      } else {
        var error = {
          status: resp.statusCode,
          message: body
        };
        renderData(error);
      }
    });
  },
  createTicketComment: function (args) {
    request(reqData.createTicketComment(args), function (err, resp, body) {
      if (err) {
        renderData(err);
      }
      if (resp !== undefined) {
        if (resp.statusCode === 201 || resp.statusCode === 200) {
          renderData(null, resp.statusCode);
        } else {
          var error = {
            status: resp.statusCode,
            message: body
          };
          console.log("124")
          renderData(error);
        }
      }
    });
  },
  searchConversation: function (args) {
    console.log("SSSSSSSSSSSSSSSSSSSSS")
    request(reqData.searchConversation(args), function (err, resp, body) {
      if (err) {
        renderData(err);
      }
      if (resp !== undefined) {
        if (resp.statusCode === 200) {
          try {
            var respObj = JSON.parse(body);
            renderData(null, respObj);
          } catch (c_err) {
            renderData(c_err);
          }
        } else {
          var error = {
            status: resp.statusCode,
            message: body
          };
          renderData(error);
        }
      }
    });
  },
  getAgents: function (args) {
    request(reqData.getAgents(args), function (err, resp, body) {
      if (err) {
        renderData(err);
      }
      if (resp !== undefined) {
        if (resp.statusCode === 201 || resp.statusCode === 200) {
          try {
            var respObj = JSON.parse(body);
            renderData(null, respObj);
          } catch (c_err) {
            renderData(c_err);
          }
        } else {
          var error = {
            status: resp.statusCode,
            message: body
          };
          renderData(error);
        }
      }
    });
  },
  searchAssignee: function (args) {
    request(reqData.searchAssignee(args), function (err, resp, body) {
      if (err) {
        renderData(err);
      }
      if (resp !== undefined) {
        if (resp.statusCode === 201 || resp.statusCode === 200) {
          try {
            var respObj = JSON.parse(body);
            renderData(null, respObj);
          } catch (c_err) {
            renderData(c_err);
          }
        } else {
          var error = {
            status: resp.statusCode,
            message: body
          };
          renderData(error);
        }
      }
    });
  },
  getTicket: function (args) {
    request(reqData.getTicket(args), function (err, resp, body) {
      if (err) {
        renderData(err);
      }
      if (resp !== undefined) {
        if (resp.statusCode === 201 || resp.statusCode === 200) {
          try {
            var respObj = JSON.parse(body);
            renderData(null, respObj);
          } catch (c_err) {
            renderData(c_err);
          }
        } else {
          var error = {
            status: resp.statusCode,
            message: body
          };
          renderData(error);
        }
      }
    });
  },
  getGroups: function (args) {
    request(reqData.getGroups(args), function (err, resp, body) {
      if (err) {
        renderData(err);
      }
      if (resp !== undefined) {
        if (resp.statusCode === 201 || resp.statusCode === 200) {
          try {
            var respObj = JSON.parse(body);
            renderData(null, respObj);
          } catch (c_err) {
            renderData(c_err);
          }
        } else {
          var error = {
            status: resp.statusCode,
            message: body
          };
          renderData(error);
        }
      }
    });
  },
  getAssinableAgents: function (args) {
    request(reqData.getAssinableAgents(args), function (err, resp, body) {
      if (err) {
        renderData(err);
      }
      if (resp !== undefined) {
        if (resp.statusCode === 201 || resp.statusCode === 200) {
          try {
            var respObj = JSON.parse(body);
            renderData(null, respObj);
          } catch (c_err) {
            renderData(c_err);
          }
        } else {
          var error = {
            status: resp.statusCode,
            message: body
          };
          renderData(error);
        }
      }
    });
  }
  ,
  getAssinableAgents: function (args) {
    request(reqData.getAssinableAgents(args), function (err, resp, body) {
      if (err) {
        renderData(err);
      }
      if (resp !== undefined) {
        if (resp.statusCode === 201 || resp.statusCode === 200) {
          try {
            var respObj = JSON.parse(body);
            renderData(null, respObj);
          } catch (c_err) {
            renderData(c_err);
          }
        } else {
          var error = {
            status: resp.statusCode,
            message: body
          };
          renderData(error);
        }
      }
    });
  }
};
// function getMinutes(str) {
//   var time = str.split(':');
//   return time[0] * 60 + time[1] * 1;
// }
// function getBusinessHours(today, content, payload) {
//   var headers = { "Authorization": "<%= iparam.app_id %>" };
//   var options = { headers: headers };
//   console.log(headers)
//   var url = "https://api.freshchat.com/app/services/app/v1/operating_hours_v2";
//   $request.get(url, options).then(function (data) {
//     try {
//       var resp = JSON.parse(data.response);
//       var days = resp.operatingHours[1].days, today_number = today.getDay(), working = resp.operatingHours[1].working;
//       today_number = today_number - 1;
//       today_number = today_number.toString();
//       // console.log(today_number)
//       // console.log(working[today_number])
//       if (today_number in days && working[today_number]) {
//         var bh_split = days[today_number].split(";");
//         var from = bh_split[0];
//         var to = bh_split[1];
//         var indian_time_from = new Date(from * 1000).toISOString().substr(11, 5);
//         var indian_time_to = new Date(to * 1000).toISOString().substr(11, 5);
//         // today = today.toISOString().substr(11, 5);
//         var now = today.getHours() * 60 + today.getMinutes();
//         console.log(now)
//         indian_time_to = getMinutes(indian_time_to);
//         indian_time_from = getMinutes(indian_time_from);
//         console.log(indian_time_from, indian_time_to);
//         if (!(now > indian_time_from) && (now < indian_time_to)) {
//           searchUser(content, payload);
//         }
//       }
//     } catch (error) {
//       renderData(error);
//     }
//   }, function (error) {
//     renderData(error);
//   });
// }
function validateEmail(email) {
  const re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  return re.test(String(email).toLowerCase());
}
function searchUser(content, payload) {
  var actor_email;
  var bodyObj = {}
  payload["body"] = bodyObj;
  console.log(payload.body)
  if (payload.data.actor.email !== null)
    actor_email = payload.data.actor.email;
  console.log("EMAIL-> ", actor_email);
  payload.email = base64.encode(actor_email);

  request(reqData.searchUser(payload), function (err, resp, body) {
    console.log(resp.statusCode)
    if (err) {
      console.error(err);
    }
    if (resp !== undefined) {
      if (resp.statusCode === 200) {
        try {
          var respObj = JSON.parse(body);
          console.log(respObj)
          console.log(respObj.users);
          if (respObj.users.length !== 0) {
            var requester_id = respObj.users[0].id;
            payload.body.requester_id = base64.encode(requester_id);
          } else {
            var name = (payload.data.actor.last_name !== null) ? payload.data.actor.first_name + payload.data.actor.last_name : payload.data.actor.first_name;
            payload.body.email = base64.encode(actor_email);
            console.log("NAME-> ", name)
            payload.body.name = base64.encode(name);
          }
          console.log(content, " <-CONTENT")
          payload.body.subject = base64.encode(content);
          payload.body.description = base64.encode(content);
          payload.body.status = base64.encode("Open");
          console.log(payload.body)
          createTicketInZendesk(payload);
          // if (respObj.users)
        } catch (c_err) {
          console.log("IN CATCH BLOCK....")
          console.error(c_err);
        }
      } else {
        var error = {
          status: resp.statusCode,
          message: body
        };
        console.error(error);
      }
    }

  });
}
function createTicketInZendesk(args) {
  console.log("in createTicketInZendesk()........................")
  request(reqData.createTicket(args), function (err, resp, body) {
    if (err) {
      console.error(err);
    }
    if (resp !== undefined) {
      if (resp.statusCode === 201) {
        console.info("Ticket created succesfully");
      } else {
        var error = {
          status: resp.statusCode,
          message: body
        };
        console.log(body.details)
        console.error(error);
      }
    }
  });
}