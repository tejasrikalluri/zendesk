$(document).ready(function () {
    app.initialized().then(function (_client) {
        window.viewTicketClient = _client;
        contextInfo(viewTicketClient);
    }, function () {
        showNotification(viewTicketClient, "error", "Something went wrong, please try again");
    });
    function contextInfo(client) {
        client.instance.context().then(function (context) {
            getTicket(context.data, client);
        }, function (error) {
            showNotification(client, "danger", error);
        });
    }
    function getTicket(c_data, client) {
        var options = {
            "ticket_id": btoa(c_data.ticket_id)
        };
        client.request.invoke("getTicket", options).then(function (data) {
            if (data.response.message === undefined) {
                var resp = data.response;
                var arr = []; const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
                    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
                ];
                var created_at = resp.ticket.created_at;
                var creatSplit = created_at.split("T")[0];
                var convert1 = new Date(creatSplit);
                var month_str1 = convert1.getDate() + " " + monthNames[convert1.getMonth()] + " " + convert1.getFullYear();
                getTicketAssignedTo(resp.ticket, client, arr, month_str1, monthNames, c_data.domain);

            }
        }, function (err) {
            showNotification(client, "alert", err.message);
        });
    }
    function getTicketAssignedTo(ticket, client, arr, month_str1, monthNames, domain) {
        if (ticket.assignee_id !== null) {
            checkAssignee(ticket.assignee_id, client, function (aData) {
                var assigneeTo = aData.user.name;
                checkAssignee(ticket.submitter_id, client, function (aData) {
                    var assignedBy = aData.user.name;
                    displayTicketDetails(arr, ticket, month_str1, monthNames, assigneeTo, assignedBy, domain);
                });

            });
        } else {
            checkAssignee(ticket.submitter_id, client, function (aData) {
                var assignedBy = aData.user.name;
                displayTicketDetails(arr, ticket, month_str1, monthNames, "~", assignedBy, domain);
            });
        }

    }
    function displayTicketDetails(arr, ticket, month_str1, monthNames, assigneeTo, assignedBy, domain) {
        arr.push(`<div class="msubject">${ticket.subject}</div>`);
        arr.push(`<div class="msubjval"><a href="https://${domain}/agent/tickets/${ticket.id}" target="_blank">#${ticket.id}</a></div>`);
        arr.push(`<p class="mcreated">Created on</p>`);
        arr.push(`<div class="val">${month_str1}</div>`);
        arr.push(`<p class="mdesc">Description</p>`);
        arr.push(`<div class="val">${ticket.description}</div>`);
        arr.push(`<p class="mdue">Due on</p>`);
        if (ticket.due_at !== null) {
            var due_at = ticket.due_at;
            var dueSplit = due_at.split("T")[0];
            var convert2 = new Date(dueSplit);
            var month_str2 = convert2.getDate() + " " + monthNames[convert2.getMonth()] + " " + convert2.getFullYear();
            arr.push(`<div class="val">${month_str2}</div>`)
        } else arr.push(`<div class="val">~</div>`);
        arr.push(`<p class="massigned">Assigned to</p>`);
        arr.push(`<div class="val">${assigneeTo}</div>`);
        arr.push(`<p class="mstatus">Status</p>`);
        arr.push(`<div class="val">${ticket.status}</div>`);
        arr.push(`<p class="mpriority">Priority</p>`);
        (ticket.priority !== null) ?
            arr.push(`<div class="val">${ticket.priority}</div>`) : arr.push(`<div class="val">~</div>`);
        arr.push(`<p class="massignedby">Assigned by</p>`);
        arr.push(`<div class="val">${assignedBy}</div>`);
        $(".viewTicket").append(arr.join('')).show();
        $(".spinner").hide();
    }
});