$(document).ready(function () {
    app.initialized().then(function (_client) {
        var append_client = _client;
        $("#append_ticket_details").hide();
        var getContextData = function (callback) {
            contextInfo(append_client, callback);
        };
        getContextData(function (c_data) {
            var page = 1;
            if (c_data.user_id !== null)
                getTickets(c_data, append_client, page);
            else {
                showNotification(append_client, "info", "No existing tickets for this User");
                $(".loader").hide();
            }
        });
        $(document).on("click", ".append", function (e) {
            $(this).prop("disabled", true);
            var obj = {};
            var arr = [];
            getContextData(function (c_data) {
                c_data.conversation.messages.reverse();
                $.each(c_data.conversation.messages, function (i, v) {
                    obj["created_at"] = v.created_time;
                    obj["actor_id"] = v.actor_id;
                    obj["message_parts"] = v.message_parts;
                    obj["actor_type"] = v.actor_type;
                    obj["message_type"] = v.message_type;
                    obj["id"] = v.id;
                    arr.push(obj);
                });
                var parse_id = parseInt(e.target.dataset.id);
                searchInDb(append_client, parse_id, arr, c_data);
            });
        });
    }, function () {
        showNotification(append_client, "danger", "Unexcepted error occured, please try again");
    });
    function searchInDb(append_client, id, arr, c_data) {
        var trimmed_id = jQuery.trim(c_data.conversation.messages[c_data.conversation.messages.length - 1].id).substring(0, 30).trim(this) + "...";
        append_client.db.get(id).then(function (d_data) {
            var db_id = d_data.conv_id;
            formAUI(append_client, c_data, id, db_id);
        }, function (error) {
            if (error.status === 404) {
                setDb(append_client, id, trimmed_id, arr, c_data, c_data.user_id);
                formUIforNote(arr, c_data, append_client, c_data.user_id, id, "append_resolve");
            } else
                showNotification(client, "danger", "Unable to fetch DB data");
        });
    }
    function setDb(client, id, trimmed_id, arr, c_data, user_id) {
        client.db.set(id, { conv_id: trimmed_id }).then(function () {
            formUIforNote(arr, c_data, client, user_id, id, "append_resolve");
        }, function (error) {
            if (error.status !== 404)
                showNotification(client, "danger", error.message);
        });
    }
    function formAUI(client, data, id, db_id) {
        var messages = data.conversation.messages;
        var last_conv_id = messages[messages.length - 1].id;
        var arr = [], ui_arr = [];
        $.each(messages, function (i, v) {
            var trimmed_id = jQuery.trim(v.id).substring(0, 30).trim(this) + "...";
            arr.push(trimmed_id);
        });
        var trimmed_id = jQuery.trim(last_conv_id).substring(0, 30).trim(this) + "...";
        if (db_id === trimmed_id)
            showNotification(client, "info", "No new message for this coonversation.")
        else {
            console.log("not equal....")
            var index = $.inArray(db_id, arr);
            console.log(db_id, trimmed_id)
            console.log(index, messages.length - 1)
            $.each(messages, function (i, v) {
                var obj = {};
                if (index === 0) {
                    if (i >= index) {
                        obj["created_at"] = v.created_time;
                        obj["actor_id"] = v.actor_id;
                        obj["message_parts"] = v.message_parts;
                        obj["actor_type"] = v.actor_type;
                        obj["message_type"] = v.message_type;
                        obj["id"] = v.id;
                        ui_arr.push(obj);
                    }
                } if (index > 0) {
                    if (i > index) {
                        obj["created_at"] = v.created_time;
                        obj["actor_id"] = v.actor_id;
                        obj["message_parts"] = v.message_parts;
                        obj["actor_type"] = v.actor_type;
                        obj["message_type"] = v.message_type;
                        obj["id"] = v.id;
                        ui_arr.push(obj);
                    }
                }
            });
            if (index != -1) {
                updateDb(client, id, trimmed_id, ui_arr, data);
                // formUIforNote(ui_arr, data, client, data.user_id, id, "append");
            }
        }

    }
    function updateDb(client, id, trimmed_id, ui_arr, data) {
        client.db.update(id, "set", { "conv_id": trimmed_id }).then(function () {
            formUIforNote(ui_arr, data, client, data.user_id, id, "append");
        }, function () {
            showNotification(client, "danger", "Failed to update DB");
        });
    }

    function contextInfo(client, callback) {
        client.instance.context().then(function (context) {
            callback(context.data);
        }, function (error) {
            showNotification(client, "danger", error);
        });
    }
    function getTickets(c_data, client, page) {
        console.log(c_data)
        var options = {
            "user_id": btoa(c_data.user_id), page: page
        };
        client.request.invoke("getAllTickets", options).then(function (data) {
            if (data.response.message === undefined) {
                var resp = data.response;
                var arr = [];
                $.each(resp.tickets, function (i, v) {
                    arr.push(`<div class="t_a"><div id="ticket_${v.id}" class="ticket_modal">`);
                    arr.push(`<p id="subject_${v.id}" class="subject_modal" title="${v.subject}">${v.subject}</p>`);
                    console.log(`https://${c_data.getSubdomain}/agent/tickets/${v.id}`)
                    arr.push(`<a href="https://${c_data.getSubdomain}/agent/tickets/${v.id}" target="_blank" id="id_${v.id}" class="id_modal">#${v.id}</a>`);
                    arr.push(`<p class="seperator_modal"></p>`);
                    var date_split = v.created_at.split("T")[0];
                    const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
                        "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
                    ];
                    var convert = new Date(date_split);
                    var month_str = convert.getDate() + " " + monthNames[convert.getMonth()] + " " + convert.getFullYear();
                    arr.push(`<table border="0" class="ticket_info_modal">
                    <tr>
                      <td class="label_info_modal">Created at</td>
                      <td id="">
                        <div class="value_info">${month_str}</div>
                      </td>
                    </tr>`);
                    if (v.due_at !== null) {
                        var date_split2 = v.due_at.split("T")[0];
                        var convert2 = new Date(date_split2);
                        var month_str2 = convert2.getDate() + " " + monthNames[convert2.getMonth()] + " " + convert2.getFullYear();
                        arr.push(`<tr>
                                  <td class="label_info_modal">Due at</td>
                                  <td id="">
                                    <div class="value_info">${month_str2}</div>
                                  </td>
                                                      </tr>`);
                    }
                    else {
                        var month_str2 = "~";
                        arr.push(`<tr>
                        <td class="label_info_modal">Due at</td>
                        <td id="">
                          <div class="value_info">${month_str2}</div>
                        </td>
                                  </tr>`);
                    }

                    arr.push(`<tr>
                              <td class="label_info_modal">
                                Status
                              </td>
                              <td id="">
                                <div class="value_info">${v.status}</div>
                              </td>
                            </tr>
                          </table>`);
                    arr.push(`</div><div id="append_area_${v.id}" class="append_area"><fw-button data-id="${v.id}" color="primary" id="append_${v.id}" class="append"> Append </fw-button></div></div>`);
                });
                $("#append_ticket_details").append(arr.join('')).show();
                $(".loader").hide();
                if (resp.tickets.length === 0)
                    showNotification(append_client, "info", "No existing tickets for this User");
            }
        }, function (err) {
            showNotification(client, "alert", err.message);
        });
    }
});