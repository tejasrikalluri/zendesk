//show notifications
function showNotification(client, type, message) {
    client.interface.trigger("showNotify", {
        type: type,
        message: message
    });
}
// get subdomain from iparams
function getSubdomainData(client, callback) {
    client.iparams.get("subdomain").then(function (data) {
        callback(data.subdomain);
    }, function () {
        showNotification(client, "alert", "Failed to fetch Iparams Subdomain.");
    });
}
var checkAssignee = function (assignee_id, client, callback) {
    var options = {
        "assignee_id": btoa(assignee_id)
    };
    client.request.invoke("searchAssignee", options).then(function (data) {
        if (data.response.message === undefined) {
            callback(data.response)
        }
    }, function (err) {
        showNotification(client, "danger", err.message);
    });
}
function formUIforNote(array, c_data, client, requester_id, id, origin) {
    var arr = [];
    console.log(array.length)
    console.log(array)
    $.each(array, function (k, v) {
        console.log(v.actor_type === "agent", v.message_type === "normal")
        console.log(v.actor_type, v.message_type)
        if ((v.actor_type === "agent") && v.message_type === "normal") {//agents messages not with private

            $.each(v.message_parts, function (k2, v2) {
                forAgentMessages(v2, arr, c_data, v.actor_id);
            });
        }
        if (v.actor_type === "user") {
            $.each(v.message_parts, function (k3, v3) {
                forReceiverMessages(v3, c_data, arr, v.actor_id);
            });
        }
    });
    console.log(arr)
    // $("#check_ui").append(arr);
    if (arr.length !== 0)
        createInternalNote(client, arr, requester_id, id, c_data, origin);
    else
        showNotification(client, "info", "No new messages for this conversation");
}
function createInternalNote(client, array, requester_id, id, c_data, origin) {
    var options = {
        body: {
            "author_id": btoa(requester_id),
            "array": array,
            "ticket_id": id,
            "conv_id": c_data.conversation.conv_id, origin: origin
        }
    };
    console.log(options.body)
    client.request.invoke("createTicketComment", options).then(function () {
        sendInstaceForNewUser(c_data, client, origin);
    }, function () {
        showNotification(client, "error", "Failed to create a note");
    });
}
function sendInstaceForNewUser(c_data, client, origin) {
    if (c_data.email !== null)
        sendDataToInstance(client, c_data.email, origin);
}
function sendDataToInstance(client, data, origin) {
    client.instance.send({
        message: {
            email: data,
            origin: origin
        }
    });
    if (origin !== "append") {
        client.instance.close();
        showNotification(client, "success", "Ticket sucessfully created.");
    } else {
        showNotification(client, "success", "Conversation has been append to respective ticket.");
    }
}
function forAgentMessages(v2, arr, data, actor_id) {
    var firstLetter = data.agent_obj[actor_id].charAt(0);
    var capital_letter = firstLetter.toUpperCase();
    if ("text" in v2) {
        checkOtherStrings(v2, arr, capital_letter, data, actor_id);
    }
    forImageAndFile(v2, arr, capital_letter, data, actor_id);
}
function checkOtherStrings(v2, arr, capital_letter, data, actor_id) {
    if (!v2.text.content.includes("Conversation was reopened by") && !v2.text.content.includes("Conversation was assigned to") && !v2.text.content.includes("Unassigned from group by") && !v2.text.content.includes("Assigned to") && !v2.text.content.includes("...requests")) {
        arr.push(`<br/><div style="margin-bottom: 45px">`);
        arr.push(`<div style="font-size:12px;font-weight:500;margin-left:70%;color:#6f7071;margin-right:36px">${data.agent_obj[actor_id]}</div>`);
        arr.push(`<img src="https://images.freshchat.com/30x30/fresh-chat-names/Alphabets/${capital_letter}.png" style="width:30px;height: 30px;border-radius:6px 50% 50% 50%;margin-left:5px;float:right;margin-right:17%" class="inline-image"/>`);
        arr.push(`<div style="float:right;border-radius:20px 4px 20px 20px;background-color:#ffffff;max-width:390px;padding:12px"><div>${v2.text.content}</div></div>`);
        arr.push(`</div><br/>`);
    }
}
function forImageAndFile(v2, arr, capital_letter, data, actor_id) {
    if ("image" in v2) {
        var image_name_index = v2.image.url.lastIndexOf("/");
        var image_name = v2.image.url.substring(image_name_index + 1);
        arr.push(`<br/><div style="margin-bottom: 45px">`);
        arr.push(`<div style="font-size:12px;font-weight:500;margin-left:70%;color:#6f7071;margin-right:36px">${data.agent_obj[actor_id]}</div>`);
        arr.push(`<img src="https://images.freshchat.com/30x30/fresh-chat-names/Alphabets/${capital_letter}.png" style="width:30px;height:30px;border-radius:6px 50% 50% 50%;margin-left:5px;float:right;margin-right:17%" class="inline-image"/>`);
        arr.push(`<div style="float:right;border-radius:20px 4px 20px 20px;background-color:#ffffff;max-width:390px;padding:12px"><div><b>Click to open the image: </b><a href="${v2.image.url}" target="_blank">${image_name}</a></div></div>`);
        arr.push(`</div><br/>`);
    }
    if ("file" in v2) {
        arr.push(`<br/><div style="margin-bottom: 45px">`);
        arr.push(`<div style="font-size:12px;font-weight:500;margin-left:70%;color:#6f7071;margin-right:36px">${data.agent_obj[actor_id]}</div>`);
        arr.push(`<img src="https://images.freshchat.com/30x30/fresh-chat-names/Alphabets/${capital_letter}.png" style="width:30px;height:30px;border-radius:6px 50% 50% 50%;margin-left:5px;float:right;margin-right:17%" class="inline-image"/>`);
        arr.push(`<div style="float:right;border-radius:20px 4px 20px 20px;background-color:#ffffff;max-width:390px;padding:12px"><div>* File attached - <b>${v2.file.name}</b></div></div>`);
        arr.push(`</div><br/>`);
    }
    if ("url_button" in v2) {
        arr.push(`<br/><div style="margin-bottom: 45px">`);
        arr.push(`<div style="font-size:12px;font-weight:500;margin-left:70%;color:#6f7071;margin-right:36px">${data.agent_obj[actor_id]}</div>`);
        arr.push(`<img src="https://images.freshchat.com/30x30/fresh-chat-names/Alphabets/${capital_letter}.png" style="width:30px;height:30px;border-radius:6px 50% 50% 50%;margin-left:5px;float:right;margin-right:17%" class="inline-image"/>`);
        arr.push(`<div style="float:right;border-radius:20px 4px 20px 20px;background-color:#ffffff;max-width:390px;padding:12px"><b>${v2.url_button.label}</b></div>`);
        arr.push(`</div><br/>`);
    }
    // arr.push(`<div style="color: #999999;font-size: 11px;clear: right;float:right;">03:11 PM, 16th Jun</div>`); 
}
function forReceiverMessages(v3, data, arr) {
    console.log("forReceiverMessages().............")
    console.log("DATA")
    console.log(data)
    arr.push(`<br/><div style="margin-bottom: 45px">`);
    var first_letter = data.name.charAt(0);
    var capital_letter = first_letter.toUpperCase();
    arr.push(`<div style="font-size: 12px;font-weight: 500;color: #6f7071;margin-left: 33px">${data.name}</div>`);
    arr.push(`<img src="https://images.freshchat.com/30x30/fresh-chat-names/Alphabets/${capital_letter}.png" style="width: 30px;height: 30px;border-radius: 6px 50% 50% 50%;margin-left: 5px;float: left;clear: right" class="inline-image"/>`);
    if ("text" in v3) {
        arr.push(`<div  style="float: left;border-radius: 20px 4px 20px 20px;background-color: #ffffff;max-width:390px;padding:12px"><div>${v3.text.content}</div></div>`);
    }
    if ("image" in v3) {
        arr.push(`<div style="float: left;border-radius: 20px 4px 20px 20px;background-color: #ffffff;max-width:390px;padding:12px"><div><b>Click to open the image: </b>a<a href="${v2.image.url}" target="_blank">${v3.image.url}</a></div></div>`);
    }
    if ("file" in v3) {
        arr.push(`<div style="float: left;border-radius: 20px 4px 20px 20px;background-color: #ffffff;max-width:390px;padding:12px"><div>* File attached - <b>${v3.file.name}</b></div></div>`);
    }
    // arr.push(`<div style="color: #999999;font-size: 11px;clear: right;float:left;margin-top: 41px;margin-left: -93px;">03:11 PM, 16th Jun</div>`);
    arr.push(`</div><br/>`);

}