$(document).ready(function () {
    app.initialized().then(function (_client) {
        var modal_client = _client;
        $("#modal-body,#partExisting,#agent,.agentLabel,.agentSpan,.existingNoTickets").hide();
        $("#m_button").prop("disabled", true);
        var getContextInfo = function (callback) {
            contextInfo(modal_client, callback);
        };
        getTicketFields(modal_client);
        $("#cancel").off().click(function () {
            modal_client.instance.close();
        });
        $("#search").off().click(function () {
            $(this).prop("disabled", true);
            var ticket_id = $("#ticketId").val().trim();
            if (ticket_id !== "") {
                $(".ticketsList").html('');
                $("#existingMsg").show();
                $("#partNew").hide();
                getTicket(ticket_id, modal_client, getContextInfo);
            } else {
                $(this).prop("disabled", false);
                showNotification(modal_client, "danger", "Please enter any Ticket ID");
            }

        });
        $(document).on('fwChange', 'fw-datepicker', function () {
            $("#m_button").prop("disabled", false);
        });
        $(document).on('input', 'input,textarea', function () {
            $("#m_button").prop("disabled", false);
        });
        $(document).on('change', 'select', function () {
            $("#m_button").prop("disabled", false);
        });
        $("#ticketId").on("change", function () {
            $("#search").prop("disabled", false);
            // if (this.value === "") {
            //     $("#existingMsg").show();
            //     $(".ticketsList").html('');
            //     getExistingTickets(getContextInfo, modal_client, "empty");
            // }
        });
        $("input[name='optradio']").click(function () {
            if ($('input:radio[name=optradio]:checked').val() === "new") {
                $("#m_button").text("Create a Zendesk ticket");
                $("#m_button").prop("disabled", true);
                $("#partNew").show();
                $("#partExisting,.existingNoTickets").hide();
            } else {
                $("#m_button").text("Append to ticket");
                // $("#m_button").prop("disabled", false);
                $(".ticketsList").html('');
                getExistingTickets(getContextInfo, modal_client, "change");
            }
        });
        $(document).on('change', '#group', function () {
            $("#agent,.agentLabel,.agentSpan").hide();
            $('#agent option:not(:first)').remove();
            var options = {
                "group_id": btoa($(this).val())
            };
            modal_client.request.invoke("getAssinableAgents", options).then(function (data) {
                if (data.response.message === undefined) {
                    var count = 0, length = data.response.group_memberships.length, arr = data.response.group_memberships;
                    agentProcess(count, length, arr, modal_client);
                }
            }, function (error) {
                showNotification(client, "danger", error.message);
            });
        });

        $(document).on('click', '#m_button', function () {
            $(this).prop("disabled", true);
            getContextInfo(function (c_data) {
                console.log("CONTEXT DATA")
                console.log(c_data)
                if ($('#m_button').text() === "Append to ticket") {
                    var arr = [], radioValue = $("input[name='optTicket']:checked").val();
                    c_data.conversation.messages.reverse();
                    $.each(c_data.conversation.messages, function (i, v) {
                        var obj = {};
                        obj["created_at"] = v.created_time;
                        obj["actor_id"] = (v.actor_id !== undefined) ? v.actor_id : v.org_actor_id;
                        obj["message_parts"] = v.message_parts;
                        obj["message_type"] = v.message_type;
                        obj["actor_type"] = v.actor_type;
                        obj["id"] = v.id;
                        console.log("CONVERSATION OBJECT")

                        console.log(obj)
                        arr.push(obj);
                    });
                    var parse_id = parseInt(radioValue);
                    console.log("CONV ARRAY")

                    console.log(arr)
                    searchInDb(modal_client, parse_id, arr, c_data);
                } else {
                    clickWithNewTicket(c_data, modal_client);
                }
            });

        });
    }, function () {
        showNotification(modal_client, "danger", "Something went wrong, please try again");
    });
    function clickWithNewTicket(c_data, modal_client) {
        var subject = $("#subject").val().trim();
        var notes = $("#notes").val().trim();
        var status = $("#status").val();
        console.log(subject, notes, status)
        var obj = {
            "body": {
                "custom_fields": {
                }
            }
        };
        if (c_data.source === "new_ticket") {
            console.log(subject !== "", notes !== "", status !== "Select", status !== "")
            if (subject !== "" && notes !== "" && status !== "Select" && status !== "") {
                checkFieldValidation(subject, notes, obj);
                obj.body["requester_id"] = btoa(c_data.user_id);
                checkValid("old", modal_client, obj, c_data.email);
            } else
                showNotification(modal_client, "danger", "Please fill mandatory fields");
        } else if (c_data.source === "new_requester")
            formNewRequester(subject, notes, c_data, modal_client, obj, "not_resolve", status);
    }
    // else if (c_data.source === "new_requester_resolve") {
    //     formNewRequester(subject, notes, c_data, modal_client, obj, "resolved");
    // } else if (c_data.source === "new_ticket_resolve") {
    //     checkFieldValidation(subject, notes, obj);
    //     obj.body["requester_id"] = btoa(c_data.user_id);
    //     checkValid("old_resolve", modal_client, obj, c_data);
    // }
    function searchInDb(modal_client, id, arr, c_data) {
        var trimmed_id = jQuery.trim(c_data.conversation.messages[c_data.conversation.messages.length - 1].id).substring(0, 30).trim(this) + "...";
        modal_client.db.get(id).then(function (d_data) {
            var db_id = d_data.conv_id;
            formAUI(modal_client, c_data, id, db_id);
        }, function (error) {
            if (error.status === 404) {
                setDb(modal_client, id, trimmed_id, arr, c_data, c_data.user_id);
            } else
                showNotification(client, "danger", "Unable to fetch DB data");
        });
    }
    function formAUI(client, data, id, db_id) {
        var messages = data.conversation.messages;
        var last_conv_id = messages[messages.length - 1].id;
        var arr = [], ui_arr = [];
        $.each(messages, function (i, v) {
            var trimmed_id = jQuery.trim(v.id).substring(0, 30).trim(this) + "...";
            arr.push(trimmed_id);
        });
        var trimmed_id = jQuery.trim(last_conv_id).substring(0, 30).trim(this) + "...";
        console.log(db_id, trimmed_id)
        if (db_id === trimmed_id)
            showNotification(client, "info", "No new message for this coonversation.")
        else {
            console.log("IN FORMAUI FUNCTION ELSE BLOCK")
            console.log("not equal....")
            var index = $.inArray(db_id, arr);
            console.log(db_id, trimmed_id)
            console.log(index, messages.length - 1)
            $.each(messages, function (i, v) {
                var obj = {};
                if (index === 0) {
                    if (i >= index) {
                        obj["created_at"] = v.created_time;
                        obj["actor_id"] = (v.actor_id !== undefined) ? v.actor_id : v.org_actor_id;

                        obj["message_parts"] = v.message_parts;
                        obj["actor_type"] = v.actor_type;
                        obj["message_type"] = v.message_type;
                        obj["id"] = v.id;
                        ui_arr.push(obj);
                    }
                } if (index > 0) {
                    if (i > index) {
                        obj["created_at"] = v.created_time;
                        obj["actor_id"] = (v.actor_id !== undefined) ? v.actor_id : v.org_actor_id;
                        obj["message_parts"] = v.message_parts;
                        obj["actor_type"] = v.actor_type;
                        obj["message_type"] = v.message_type;
                        obj["id"] = v.id;
                        ui_arr.push(obj);
                    }
                }
            });
            if (index != -1) {
                updateDb(client, id, trimmed_id, ui_arr, data, ui_arr, data);
            }
        }

    }
    function setDb(client, id, trimmed_id, arr, c_data, user_id) {
        client.db.set(id, { conv_id: trimmed_id }).then(function () {
            console.log("199")
            console.log("set DB successfully")
            formUIforNote(arr, c_data, client, user_id, id, "append");
        }, function (error) {
            if (error.status !== 404)
                showNotification(client, "danger", error.message);
        });
    }
    function getExistingTickets(getContextInfo, modal_client, source) {
        getContextInfo(function (data) {
            $("#partExisting label:first").html(`Enter an existing ticket " ${data.name} "`);
            $("#ticketsOf").html(`Tickets of ${data.name} in last 30 days`);
            $("#partExisting,#existingMsg").show();
            $("#partNew").hide();
            if (source === "change") {
                $("#ticketsLoad").hide();
            }
            if (data.source === "new_ticket") {
                getTickets(data, modal_client);
                $("#m_button").prop("disabled", false);
            } else {
                $("#m_button").prop("disabled", true);
                $("#partExisting,#existingMsg").hide();
                $(".existingNoTickets").show();
            }
        });

    }
    function getTicket(ticket_id, client, c_data) {
        var options = {
            "ticket_id": btoa(ticket_id)
        };
        client.request.invoke("getTicket", options).then(function (data) {
            if (data.response.message === undefined) {
                var resp = data.response, arr = [];
                formTicketUi(resp.ticket, arr, 0, c_data);
                $(".ticketsList").append(arr.join('')).show();
                $("#ticketsLoad").show();
                $(".ticketShow:nth-child(1)").find('input[type=radio]').attr('checked', true);
                $(".existingMsg").hide();
            }
        }, function (err) {
            $(".existingMsg").hide();
            showNotification(client, "alert", err.message);
        });
    }
    function textTruncate(subject, id) {
        var shortname = (subject.length > 65) ? subject.substring(0, 65) + "... " + "#" + id : subject + " #" + id
        return shortname;
    }
    function getTickets(c_data, client) {
        var options = {
            "user_id": btoa(c_data.user_id)
        };
        client.request.invoke("searchTickets", options).then(function (data) {
            if (data.response.message === undefined) {
                var resp = data.response;
                var arr = [];
                console.log(resp.tickets)
                $.each(resp.tickets, function (i, v) {
                    if (i <= 2) {
                        formTicketUi(v, arr, i, c_data);
                    }
                });
                $(".ticketsList").append(arr.join('')).show();

                $("#ticketsLoad").show();
                $(".ticketShow:nth-child(1)").find('input[type=radio]').attr('checked', true);
                $(".loader,.existingMsg").hide();
            }
        }, function (err) {
            showNotification(client, "alert", err.message);
        });
    }
    function updateDb(modal_client, id, conv_id, ui_arr, data) {
        var trimmed_id = jQuery.trim(conv_id).substring(0, 30).trim(this) + "...";
        modal_client.db.update(id, "set", { "conv_id": trimmed_id }).then(function () {
            formUIforNote(ui_arr, data, modal_client, data.user_id, id, "append");
            showNotifications(modal_client, "Updated succesfully", "success");
        }, function () {
            showNotifications(modal_client, "Unexpected error occured, please try again later!", "alert");
        });
    }
    function formTicketUi(v, arr, i, c_data) {
        var subject = textTruncate(v.subject, v.id);
        var date_split = v.created_at.split("T")[0];
        var convert = new Date(date_split);
        const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
            "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
        ];
        var month_str = convert.getDate() + " " + monthNames[convert.getMonth()] + " " + convert.getFullYear();

        arr.push(`<div class="ticketShow"><div><input type="radio" name="optTicket" value="${v.id}"><a id="subject_${i}"title="${v.subject}" href="https://${c_data.domain}/agent/tickets/${v.id}" target="_blank" class="m_subject">${subject}</a></div>`);
        if (v.due_at !== null) {
            var date_split2 = v.due_at.split("T")[0];
            var convert2 = new Date(date_split2);
            var month_str2 = convert2.getDate() + " " + monthNames[convert2.getMonth()] + " " + convert2.getFullYear();
            arr.push(`<div>${c_data.name} | Created at ${month_str} | Due at ${month_str2} </div></div>`);
        }
        else {
            var month_str2 = "~";
            arr.push(`<div>${c_data.name} | Created at ${month_str} | Due at ${month_str2} </div></div>`);

        }
        return arr;
    }

    function checkFieldValidation(subject, notes, obj) {
        $("#m_button").attr("data-id", "valid");
        var regex = /.(?=.{4})/mg;
        var subst = 'X';
        $("input[type='text'],input[type='number']").each(function () {
            console.log("NUMBER TEXT BOX LOOP ID OF FIELDS")
            console.log("-------------------------------------------")

            if ($(this).val().trim() !== "") {
                console.log($(this).attr("id"))
                if ($(this).attr("id") !== "subject" && $(this).attr("id") !== "notes" && $(this).attr("id") !== "tags") {
                    if ($(this).attr("class").includes("partialcreditcard")) {
                        var value = $(this).val();
                        obj.body.custom_fields[$(this).attr("id")] = btoa(value.replace(regex, subst));
                    } else {

                        obj.body.custom_fields[$(this).attr("id")] = btoa($(this).val());
                    }
                } else {
                    console.log("TAGS ID CONDITION")
                    console.log($(this).attr("id") === "tags")
                    if ($(this).attr("id") === "tags")
                        obj.body["tags"] = btoa($(this).val());
                }
            }
            // else {
            //     $("#m_button").attr("data-id", "not_valid");
            //     return false;
            // }
        });
        $("fw-datepicker").each(function () {
            formDatePickerBody(this, obj);
        });
        $("select").each(function () {
            formSelectFieldBody(this, obj);
        });
        $("textarea").each(function () {
            formTextareaBody(this, obj);
        });
        $("input[type='checkbox']").each(function () {
            formCheckboxBody(this, obj);
        });
        obj.body["subject"] = btoa(subject);
        obj.body["description"] = btoa(notes);
    }
    function formSelectFieldBody(ele, obj) {
        if ($(ele).prop("multiple")) {
            var array = $(ele).val();
            if (array.length !== 0)
                obj.body.custom_fields[$(ele).prop("id")] = btoa(array);
            // else
            //     $("#m_button").attr("data-id", "not_valid");

        } else {
            console.log("SINGLE SELECT IDS")
            console.log($(ele).attr("id"))
            if ($(ele).val() !== "Select" && $(ele).val() !== "") {
                otherSelects(ele, obj);
            }


        }
    }
    function otherSelects(ele, obj) {
        if ($(ele).attr("id") !== "agent" && $(ele).attr("id") !== "status" && $(ele).attr("id") !== "priority" && $(ele).attr("id") !== "group")
            obj.body.custom_fields[$(ele).attr("id")] = btoa($(ele).val());
        else
            obj.body[$(ele).attr("id")] = btoa($(ele).val());
    }
    function formCheckboxBody(ele, obj) {
        if ($(ele).prop("checked")) {
            obj.body.custom_fields[$(ele).attr("id")] = btoa(true);
        }
        else
            obj.body.custom_fields[$(ele).attr("id")] = btoa(false);
    }
    function formTextareaBody(ele, obj) {
        if ($(ele).attr("id") !== "notes" && $(ele).val().trim() !== "") {
            obj.body.custom_fields[$(ele).attr("id")] = btoa($(ele).val());
        }
    }
    function formNewRequester(subject, notes, c_data, modal_client, obj, origin, status) {
        $("#m_button").attr("data-id", "valid");
        console.log(status !== "", notes !== "", c_data.email !== null, status !== "Select", status !== "")
        if (subject !== "" && notes !== "" && c_data.email !== null && status !== "Select" && status !== "") {
            checkFieldValidation(subject, notes, obj);
            obj.body["name"] = btoa(c_data.name);
            if (c_data.email !== null) { obj.body["email"] = btoa(c_data.email) }
            checkOrigin(origin, modal_client, obj, c_data);
        } else
            showNotification(modal_client, "danger", "Please fill mandatory fields");
    }
    function formDatePickerBody(ele, obj) {
        if ($(ele).val().trim() !== "")
            obj.body.custom_fields[$(ele).attr("id")] = btoa($(ele).val());
        // else
        //     $("#m_button").attr("data-id", "not_valid");
    }
    function checkValid(origin, modal_client, obj, data) {
        console.log("BEFORE TICKET CREATION OBJ")
        console.log(obj)
        console.log($("#m_button").attr("data-id"))
        if ($("#m_button").attr("data-id") === "valid")
            ticketCreate(modal_client, obj, data, origin);
        else
            showNotification(modal_client, "danger", "Please fill mandatory fields");
    }
    function checkOrigin(origin, modal_client, obj, c_data) {
        (origin !== "resolved") ? checkValid("new", modal_client, obj, c_data) : checkValid("old_resolve", modal_client, obj, c_data);
    }
    function agentProcess(count, length, arr, client) {
        if (count < length) {
            searchAgent(client, count, length, arr);
        }
        else {
            $("#agent,.agentLabel,.agentSpan").show();
        }
    }

    function searchAgent(client, count, length, arr) {
        var options = {
            "assignee_id": btoa(arr[count].user_id)
        };
        client.request.invoke("searchAssignee", options).then(function (data) {
            if (data.response.message === undefined) {
                $('#agent')
                    .append($("<option></option>")
                        .attr("value", data.response.user.id)
                        .text(data.response.user.name));
                var new_count = count + 1;
                agentProcess(new_count, length, arr, client);
            }
        }, function () {
            showNotification(client, "danger", "Failed to Agent details");
        });
    }


    function getTicketFields(client) {
        var options = {};
        client.request.invoke("getTicketFields", options).then(function (data) {
            if (data.response.message === undefined) {
                console.log("TICKET FIELDS")
                console.log(data.response.ticket_fields);
                var arr = [];
                $.each(data.response.ticket_fields, function (i, v) {
                    // console.log(v.type)
                    if (v.type === "status") {
                        $.each(v.system_field_options, function (i1, v2) {
                            $('#status')
                                .append($("<option></option>")
                                    .attr("value", v2.value)
                                    .text(v2.name));
                        });

                    }
                    if (v.type === "priority") {
                        $.each(v.system_field_options, function (i1, v2) {
                            $('#priority')
                                .append($("<option></option>")
                                    .attr("value", v2.value)
                                    .text(v2.name));
                        });
                    }
                    formCustomFields(v, arr);

                });
                getGroups(client);
                console.log(arr.length);
                $("#partNew").append(arr.join('')).show();
                formSelectFields(data);
            }
        }, function (err) {
            console.log(err);
            showNotification(client, "danger", "Failed to fetch Ticket fields");
        });
    }
    function formCustomFields(v, arr) {
        console.log("IN FORMCUSTOMFIELDS FUNCTION()............")
        console.log(v)
        if (v.visible_in_portal && v.active && v.type !== "assignee" && v.type !== "priority" && v.type !== "description" && v.type !== "subject") {
            console.log(v.type)
            formTextFields(v, arr);
        }
    }
    function formTextFields(v, arr) {
        if (v.type === "text" || v.type === "regexp") {
            arr.push(`<label>${v.title}</label><br/>`);
            arr.push(`<input id="${v.id}" type="text" class="custom_fields custom_fields_${v.id} form-control" required>
</input>`);
        }
        else if (v.type === "partialcreditcard") {
            arr.push(`<label>${v.title}</label><br/>`);
            arr.push(`<input id="${v.id}" type="text" class="custom_fields custom_fields_${v.id} form-control partialcreditcard" required>
        
</input>`);
        } else
            appendUI(v, arr);
    }
    function formSelectFields(data) {
        console.log("in formSelectFields()..............")
        console.log(data)
        $.each(data.response.ticket_fields, function (i, v) {
            if (v.type === "tagger" || v.type === "multiselect") {
                if (v.type === "tagger")
                    $(`#${v.id}`).append($("<option></option>").text("Select"));
                $.each(v.custom_field_options, function (i1, v1) {
                    $(`#${v.id}`).append($("<option></option>")
                        .text(v1.value));
                });
            }
            if (v.type === "multiselect") {
                $(`#${v.id}`).select2({});
            }
        });
    }
    function appendUI(v, arr) {
        // console.log(v.type)
        if (v.type === "textarea") {
            arr.push(`<label>${v.title}</label><br/>`);
            arr.push(`<textarea cols=98 rows=3 id="${v.id}" class="custom_fields custom_fields_${v.id} form-control" required>
          </textarea>`);
        }
        else if (v.type === "integer" || v.type === "decimal") {
            arr.push(`<label>${v.title}</label><br/>`);
            arr.push(`<input id="${v.id}" type="number" class="custom_fields custom_fields_${v.id} form-control" required>
    </input>`);
        } else if (v.type === "tagger") {
            arr.push(`<label>${v.title}</label><br/>`);
            arr.push(`<select class="custom_fields custom_fields_${v.id} form-control" id="${v.id}"></select>`);
        } else {
            appendOtherFields(v, arr);
        }
    }
    function appendOtherFields(v, arr) {
        // console.log(v.type)
        if (v.type === "multiselect") {
            arr.push(`<label>${v.title}</label><br/>`);
            arr.push(`<select class="custom_fields custom_fields_${v.id}" id="${v.id}" name="${v.title}[]" multiple="multiple"></select>`);
        } else if (v.type === "checkbox") {
            arr.push(`<div class="checkbox">
            <label><input type="checkbox" id="${v.id}">${v.title}</label>
          </div>`);
        }
        else if (v.type === "date") {
            arr.push(`<label>${v.title}</label><br/>
            <fw-datepicker date-format="YYYY-MM-DD" id="${v.id}" class="custom_fields custom_fields_${v.id}" required></fw-datepicker>`);
        }
    }
    function getGroups(client) {
        var options = {};
        client.request.invoke("getGroups", options).then(function (data) {
            if (data.response.message === undefined) {
                $.each(data.response.groups, function (i, v) {
                    $('#group')
                        .append($("<option></option>")
                            .attr("value", v.id)
                            .text(v.name));
                });
                $(".spinner,#partExisting").hide();
                $("#modal-body").show();
                // $("#m_button").prop("disabled", false);
            }
        }, function () {
            showNotification(client, "danger", "Failed to fetch Groups");
        });
    }

    function ticketCreate(client, options, c_data, origin) {
        client.request.invoke("createTicket", options).then(function (data) {
            if (data.response.message === undefined) {
                var requester_id = atob(data.response.requester_id);
                if (origin === "old") {
                    sendDataToInstance(client, c_data, origin);//user_id
                }
                else if (origin === "new") {
                    sendInstaceForNewUser(c_data, client, origin);
                }
                else {
                    linkToZendesk(client, data.response.id, c_data, requester_id, origin);
                }
            }
        }, function (error) {
            if (error.status === 400 || error.status === 422)
                showNotification(client, "danger", error.message.details.base[0].description);
            else
                showNotification(client, "danger", error.message);
        });
    }
    function linkToZendesk(modal_client, id, c_data, requester_id, origin) {
        var conv_id = c_data.conversation.messages[c_data.conversation.messages.length - 1].id;
        var trimmed_id = jQuery.trim(conv_id).substring(0, 30).trim(this) + "...";
        modal_client.db.set(id, { conv_id: trimmed_id }).then(function () {
            var arr = [];
            c_data.conversation.messages.reverse();
            $.each(c_data.conversation.messages, function (k, v) {
                var obj = {};
                obj["created_at"] = v.created_time;
                obj["actor_id"] = (v.actor_id !== undefined) ? v.actor_id : v.org_actor_id;
                obj["message_parts"] = v.message_parts;
                obj["actor_type"] = v.actor_type;
                obj["message_type"] = v.message_type;
                obj["id"] = v.id;
                arr.push(obj);
            });
            console.log("601")
            formUIforNote(arr, c_data, modal_client, requester_id, id, origin);
        }, function (error) {
            if (error.status !== 404)
                showNotification(modal_client, "error", error.message);
        });
    }
    //get instance data
    function contextInfo(client, callback) {
        client.instance.context().then(function (context) {
            callback(context.data);
        }, function (error) {
            showNotification(client, "danger", error);
        });
    }
});